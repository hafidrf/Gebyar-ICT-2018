<?php 
$route['admin/dashboard'] = 'AdminController/index';
$route['admin/data-pembayaran'] = 'AdminController/dataPembayaran';
$route['admin/konfirmasi-pembayaran/(:num)'] = 'AdminController/konfirmasiPembayaran/$1';
$route['admin/batal-konfirmasi-pembayaran/(:num)'] = 'AdminController/batalKonfirmasiPembayaran/$1';