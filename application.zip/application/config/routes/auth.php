<?php
$route['registrasi'] = 'AuthController/register';
$route['registrasi'] = 'AuthController/register';
$route['login'] = 'AuthController/login';
$route['ict-login'] = 'AuthController/login_admin';
$route['store-admin'] = 'AuthController/store_admin';
$route['logout'] = 'AuthController/logout';
