<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * 
	 */
	public function __cunstruct()
	{
		parent::__cunstruct();
	}
	/**
	 * Default method
	 */
	public function index()
	{	
		return view('welcome');
	}

	public function cdc()
	{
		return view('cdc');
	}

	public function cinema()
	{
		return view('cinema');
	}
}
