<?php $__env->startSection('title', 'ICT | Dashboard'); ?>
<?php $__env->startSection('content'); ?>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Pembayaran</h3>
            <?php if(empty($data->status) || $data->status == 0): ?>
              <div class="alert alert-info">
              Pembayaran lomba bisa di transfer ke rekening di bawah ini
              <ul>
                <li>Bank BCA 8935014596 an: Hafid Rizqifaluthi</li>
                <li>Bank BTN 0102901610015490  an :Iffatul Izzah</li>
              </ul>
              </div>
              <a href="<?php echo e(base_url('user/konfirmasi-pembayaran')); ?>" class="btn btn-sm btn-danger mb-2">Konfirmasi Pembayaran</a>
            <?php else: ?>
              <div class="alert alert-info" role="alert">
                Pembayaran telah dikonfirmasi
              </div>
            <?php endif; ?>
            <table class="table table-stripped table-responsive">
              <thead>
                <th>Ketua</th>
                <th>Kategori Lomba</th>
                <th>Judul</th>
                <th>Tim</th>
                <th>Anggota</th>
                <th>Link Video Teaser</th>
                <th>Status Pembayaran</th>
              </thead>
              <tbody>
                <tr>
                  <td><?php echo e($data->nama); ?></td>
                  <td><?php echo e($data->nama_kategori); ?></td>
                  <td><?php echo e($data->judul_aplikasi); ?></td>
                  <td><?php echo e($data->nama_tim); ?></td>
                  <td>
                    <li><?php echo e($data->anggota_1); ?></li>
                    <li><?php echo e($data->anggota_2); ?></li>
                  </td>
                  <td><?php echo e($data->link_video); ?></td>
                  <td>
                    <?php if(isset($data->status)): ?>
                      <?php echo e($data->status == 0 ? 'menunggu konfirmasi admin' : 'telah dibayar'); ?>

                    <?php else: ?>
                      menunggu pembayaran
                    <?php endif; ?>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>