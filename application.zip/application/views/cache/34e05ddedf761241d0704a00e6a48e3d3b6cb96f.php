<!DOCTYPE html>
<html lang="en">
	<head>
	<title><?php echo $__env->yieldContent('title', 'ICT'); ?></title>

	  	<?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</head>
<body>

			<?php  $CI = &get_instance();  ?>

              <?php if($CI->session->flashdata('error')): ?>
                <div class="alert alert-danger" role="alert">
                  <?php echo $CI->session->flashdata('error'); ?>

                </div>
              <?php endif; ?>
              
	<section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content">
      <div class="logo">
        <h1> Login</h1>
      </div>
      <div class="login-box">
			
			<?php 
				$attributes = array('class' => 'login-form');
				echo form_open('login', $attributes);
			 ?>
				<h3 class="login-head">
				<i class="fa fa-lg fa-fw fa-user"></i>Login
				</h3>
				<div class="form-group">	
					<label>Email</label>
					<?php echo form_error('email'); ?>    
				  	<input type="email" class="form-control <?php echo e(has_error('email')); ?>" placeholder="Email" name="email" value="<?php echo set_value('email'); ?>">
				</div>

				<div class="form-group">
					<label>Password</label>
					<?php echo form_error('password'); ?> 
				    <input class="form-control <?php echo e(has_error('password')); ?>" type="password" name="password">
				</div>
				
			    <div class="form-group">
			        <button type="submit" class="btn btn-secondary btn-block"> Login  </button>
			    </div>  
			    <div class="form-group">
			    	Belum punya akun ?
			    	<a href="<?php echo e(base_url('registrasi')); ?>">
				    	Daftar
			    	</a>
			    </div>    
			                                           
			</form>
			</article> <!-- card-body end .// -->
			
			</section>
		</div> 

	</div>
	<?php echo $__env->make('partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>