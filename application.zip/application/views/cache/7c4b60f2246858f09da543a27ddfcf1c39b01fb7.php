<?php $__env->startSection('title', 'ICT-Admin | Dashboard'); ?>
<?php $__env->startSection('content'); ?>
      <div class="row">
        <div class="col-md-12">
        <?php 
          $CI = &get_instance();
         ?>
        <?php if($CI->session->flashdata()): ?>
                <div class="alert alert-<?php echo e($CI->session->flashdata('btn')); ?>" role="alert">
                  <?php echo $CI->session->flashdata('message'); ?>

                </div>
              <?php endif; ?>
          <div class="tile">
            <h3 class="tile-title">Pembayaran</h3>
           
            <table class="table table-hovered table-responsive" id="user">
              <thead>
                <th>No</th>
             
                <th>Ketua</th>
                <th>Kategori Lomba</th>
                <th>Judul</th>
                <th>Nama Tim</th>
                <th>Status Pembayaran</th>
                <th>Bukti Transfer</th>
                <th>Aksi</th>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  
                  <td><?php echo e($user->nama); ?></td>
                  <td><?php echo e($user->nama_kategori); ?></td>
                  <td><?php echo e($user->judul_aplikasi); ?></td>
                  <td><?php echo e($user->nama_tim); ?></td>
                  <td>
                    <?php if($user->status == 0): ?>
                      Belum terkonfirmasi
                    <?php else: ?>
                      Terkonfirmasi
                    <?php endif; ?>
                  </td>
                  <td> 
                    <a target="_blank" href="<?php echo e(base_url('uploads/pembayaran/').$user->bukti_transfer); ?>">Lihat</a> 
                  </td>
                  <td>
                    <?php if($user->status == 0): ?>
                      <a href="<?php echo e(base_url('admin/konfirmasi-pembayaran/').$user->id_pembayaran); ?>">
                        Konformasi
                      </a>
                    <?php else: ?>
                      <a href="<?php echo e(base_url('admin/batal-konfirmasi-pembayaran/').$user->id_pembayaran); ?>">
                        Batalkan Konformasi
                      </a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="7"> Belum ada peserta terdaftar</td>
                </tr>
                <?php endif; ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(base_url('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(base_url('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script type="text/javascript">
      $(document).ready(function() {
          $('#user').DataTable();
      } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>