<?php $__env->startSection('title', 'ICT | Dashboard'); ?>
<?php $__env->startSection('content'); ?>
	<?php if($user->kategori_id != 1): ?>
		<?php if($proposal): ?>
			<div class="alert alert-primary">
				Proposal telah terkirim <a href="<?php echo e(base_url('uploads/proposal/').$proposal->proposal); ?>"><i class="fa fa-file-pdf-o"></i> Cek</a>
			</div>
		<?php else: ?>
			<?php if($status == 'unconfirmed'): ?>
				<div class="alert alert-primary">
					Menunggu konfirmasi pembayaran dari admin
				</div>
			<?php elseif($status == 'confirmed'): ?>
				<div class="alert alert-danger">
				Download template proposal 
				<a href="<?php echo e(base_url('uploads/proposal/template-proposal.docx')); ?>">
					<i class="fa fa-file-pdf-o"> Download</i>	
				</a>
				</div>
				<div class="tile">
				<?php 
					echo form_open_multipart(base_url('user/proposal/submit'));
				 ?>
		               
		                <div class="col-sm-12 form-group">
		                  <input type="file" class="form-control" name="pembayaran">
		                  <small class="text-muted">
		                    Unggah proposal
		                  </small>
		                </div>
		                <div class="col-sm-12 form-group">
		                  <button type="submit" class="btn btn-primary">Unggah</button>
		                </div>
		              </form>
		        </div>
			<?php elseif($status == 'not-yet-paid'): ?>
				<div class="alert alert-warning">
					Harap melakukan pemabayaran dan melakukan konfirmasi
				</div>
				<a class="btn btn-danger" href="<?php echo e(base_url('user/konfirmasi-pembayaran')); ?>">
					Konfirmasi pembayaran
				</a>
			<?php else: ?>
				<div class="alert aler-danger">
					Server error, please contact the administrator
				</div>
			<?php endif; ?>
		<?php endif; ?>	
	<?php else: ?>
		<div class="alert alert-primary">
			Peserta lomba drone race tidak perlu upload proposal
		</div>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>