<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge, chrome=1">
  <title>ICT - Himpunan Mahasiswa Jurusan Teknik Informatika UIN Maulana Malik Ibrahim Malang</title>
  <link rel="icon shortcut" href="assets/landing/assets/ict_logo_Images/ict_logo_ImgID1.png">
  <link rel="preload" href="assets/landing/css/style.css" as="style">
  <link rel="preload" href="assets/landing/css/bootstrap.min.css" as="style">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" as="stylesheet" rel="preload">
  <link rel="stylesheet" href="assets/landing/css/bootstrap.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/landing/css/style.css">
</head>

<body>
  <div id="app">
    <nav @click.stop class="navbar-panel " :class="{scrolled:navbar.scrolled,show:navbar.show}">
      <div class="container">
        <div class="mini-nav" v-if="isMobile">
          <i @click.stop="navbar.show = !navbar.show" class="fa fa-bars"></i>
        </div>
        <ul ref="link-wrapper" class="link-wrapper" :style="{height:isMobile?trigger:scrollHeight}">
          <li class="link-item">
            <a @click.prevent="hashLink('#home')" href="#home">HOME</a>
          </li>
          <li class="link-item">
            <a @click.prevent="hashLink('#events')" href="#events">EVENTS</a>
          </li>
          <li class="link-item">
            <a @click.prevent="hashLink('#gallery')" href="#gallery">GALLERY</a>
          </li>
          <li class="link-item">
            <a @click.prevent="hashLink('#contact')" href="#contact">CONTACT</a>
          </li>
          <li class="link-item" :style="{margin:isMobile?'0':'null'}">
            <a href="./login" :style="{display:isMobile?'block':'inline-block'}" class="btn btn-warning btn-login">LOG IN</a>
          </li>
        </ul>
      </div>
    </nav>
    
    <section class="event">
      
    </section>
</body>

</html>