<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge, chrome=1">
  <title>ICT - Himpunan Mahasiswa Jurusan Teknik Informatika UIN Maulana Malik Ibrahim Malang</title>
  <link rel="icon shortcut" href="assets/landing/assets/ict_logo_Images/ict_logo_ImgID1.png">
  <link rel="preload" href="assets/landing/css/style.css" as="style">
  <link rel="preload" href="assets/landing/css/bootstrap.min.css" as="style">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/assets/landing/assets/landing/css/font-awesome.min.css" as="stylesheet" rel="preload">
  <link rel="stylesheet" href="assets/landing/css/bootstrap.min.css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/assets/landing/assets/landing/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/landing/css/style.css">
</head>

<body>
  <div id="app">
    <nav @click.stop class="navbar-panel " :class="{scrolled:navbar.scrolled,show:navbar.show}">
      <div class="container">
        <div class="mini-nav" v-if="isMobile">
          <i @click.stop="navbar.show = !navbar.show" class="fa fa-bars"></i>
        </div>
        <ul ref="link-wrapper" class="link-wrapper" :style="{height:isMobile?trigger:scrollHeight}">
          <li class="link-item">
            <a href="#">HOME</a>
          </li>
          <li class="link-item">
            <a href="#">EVENTS</a>
          </li>
          <li class="link-item">
            <a href="#">GALLERY</a>
          </li>
          <li class="link-item">
            <a href="#">CONTACT</a>
          </li>
        </ul>
      </div>
    </nav>
    <header class="hero">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-xs-12">
            <img src="assets/landing/assets/ict_logo_Images/ict_logo_ImgID1.png" class="hero-img" alt="ICT 2018, Lomba IT ICT Malang, Ngoding, Event Malang, Drone, Start up, Hackathon">
          </div>
          <div class="col-md-6 col-xs-12">
            <h1 class="title">ENJOY THIS EVENT</h1>
            <p class="desc">Get in touch with us now</p>
            <a href="<?php echo e(base_url('registrasi')); ?>" class="mt-2 btn btn-primary text-uppercase">Enroll Your Team</a>
          </div>
        </div>
      </div>
    </header>
    <section class="event bg-icon">
      <div class="container">
        <div class="text-center mb-4">
          <h2 class="section-title mb-2">EVENTS</h2>
          <p class="section-desc">Here is our whole events that we had</p>
        </div>
        <div class="row single-event-wrapper">
          <div class="col-md-4 col-xs-12 single-event">
            <div v-if="eventSelected === 'drone'" @click="eventSelected=null" class="close-btn">&times;</div>
            <div class="img-container">
              <img class="single-img" src="assets/landing/assets/drone.png" alt="Lomba Drone Racing, Balapan Drone, Event Malang">
            </div>
            <h1 class="event-title text-center">DRONE RACING</h1>
            <div class="event-schedule-container">
              <transition name="fade" mode="out-in">
                <p v-if="eventSelected !== 'drone'" class="event-desc mt-3">
                  Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab ullam deleniti maxime aperiam repellendus, dolore officiis at,
                  accusantium amet sit facilis voluptatum optio obcaecati! Voluptas porro soluta obcaecati? Et, est. Voluptates
                  quia ipsam sequi doloremque mollitia incidunt illo reiciendis natus ipsum a id, distinctio sapiente unde
                  praesentium blanditiis repellat voluptatibus!
                </p>
                <div class="" v-else>
                  <p class="event-disc text-center">This is our schedule for this event.</p>
                  <ul class="event-schedule">
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                  </ul>
                </div>
              </transition>
            </div>
            <div class="action-wrapper row" v-if="eventSelected !== 'drone'">
              <button @click="selectEvent('drone')" class="btn btn-default">SCHEDULE</button>
              <a href="<?php echo e(base_url('registrasi')); ?>" class="btn btn-primary">JOIN IN</a>
            </div>
          </div>
          <div class="col-md-4 col-xs-12 single-event">
            <div v-if="eventSelected === 'cdc'" @click="eventSelected=null" class="close-btn">&times;</div>
            <div class="img-container">
              <img class="single-img" src="assets/landing/assets/CDC.png" alt="Lomba Start Up, Memecahkan masalah, ngoding, Event Malang">
            </div>
            <h1 class="event-title text-center">CDC</h1>
            <div class="event-schedule-container">
              <transition name="fade" mode="out-in">
                <p v-if="eventSelected !== 'cdc'" class="event-desc mt-3">
                  Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab ullam deleniti maxime aperiam repellendus, dolore officiis at,
                  accusantium amet sit facilis voluptatum optio obcaecati! Voluptas porro soluta obcaecati? Et, est. Voluptates
                  quia ipsam sequi doloremque molli.
                </p>
                <div v-else>
                  <p class="event-disc text-center">This is our schedule for this event.</p>
                  <ul class="event-schedule">
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                  </ul>
                </div>
              </transition>
            </div>
            <div class="action-wrapper row" v-if="eventSelected !== 'cdc'">
              <button @click="selectEvent('cdc')" class="btn btn-default">SCHEDULE</button>
              <a href="<?php echo e(base_url('registrasi')); ?>" class="btn btn-primary">JOIN IN</a>
            </div>
          </div>
          <div class="col-md-4 col-xs-12 single-event">
            <div v-if="eventSelected === 'cinema'" @click="eventSelected=null" class="close-btn">&times;</div>
            <div class="img-container">
              <img class="single-img" src="assets/landing/assets/Cinema.png" alt="Lomba Drone Racing, Balapan Drone, Event Malang">
            </div>
            <h1 class="event-title text-center">CINEMATOGRAPHY</h1>
            <div class="event-schedule-container">
              <transition name="fade" mode="out-in">
                <p v-if="eventSelected !== 'cinema'" class="event-desc mt-3">
                  Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab ullam deleniti maxime aperiam repellendus, dolore officiis at,
                  accusantium amet sit facilis voluptatum optio obcaecati! Voluptas porro soluta obcaecati? Et, est. Voluptates
                  quia ipsam sequi doloremque mollitia incidunt illo reiciendis natus ipsum a id.
                </p>
                <div v-else>
                  <p class="event-disc text-center">This is our schedule for this event.</p>
                  <ul class="event-schedule">
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                    <li class="row">
                      <div class="col-2">
                        <i class="fa fa-apple"></i>
                      </div>
                      <div class="col-10">
                        <p class="text-bold title">1 Agustus</p>
                        <p class="desc">Lorem ipsum dolor sit amet.</p>
                      </div>
                    </li>
                  </ul>
                </div>
              </transition>
            </div>
            <div class="action-wrapper row" v-if="eventSelected !== 'cinema'">
              <button @click="selectEvent('cinema')" class="btn btn-default">SCHEDULE</button>
              <a href="<?php echo e(base_url('registrasi')); ?>" class="btn btn-primary">JOIN IN</a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="media-partner">
      <div class="container py-2">
        <h2 class="section-title">MEDIA PARTNER</h2>
        <div class="text-center">
          <div class="upper mt-4">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/acaramahasiswa_Images/acaramahasiswa_ImgID1.png" alt="Acara Malang">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/acaramalang_Images/acaramalang_ImgID1.png" alt="Acara Mahasiswa">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/al_fataa_Images/al_fataa_ImgID1.png" alt="Acara Mahasiswa">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/devc_Images/devc_ImgID1.png" alt="devc">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/dsc_Images/dsc_ImgID1.png" alt="dsc">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/eth0_Images/eth0_ImgID1.png" alt="eth0">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/fun_java_Images/fun_java_ImgID1.png" alt="fun_java">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/infokost_Images/infokost_ImgID1.png" alt="infokost">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/inipolinema_Images/inipolinema_ImgID1.png" alt="inipolinema">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/kampus_malang_Images/kampus_malang_ImgID1.png" alt="kampus_malang">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/mampus_Images/mampus_ImgID1.png" alt="mampus">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/mamud_Images/mamud_ImgID1.png" alt="mamud">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/mhs_mlg_Images/mhs_mlg_ImgID1.png" alt="mhs_mlg">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/mhs_polinema_Images/mhs_polinema_ImgID1.png" alt="mhs_polinema">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/mhs_ub_Images/mhs_ub_ImgID1.png" alt="mhs_ub">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/mocap_Images/mocap_ImgID1.png" alt="mocap">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/ontaki_Images/ontaki_ImgID1.png" alt="ontaki">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/siswa_malang_Images/siswa_malang_ImgID1.png" alt="siswa_malang">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/uinbuntu_Images/uinbuntu_ImgID1.png" alt="uinbuntu">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/weboender_Images/weboender_ImgID1.png" alt="weboender">
          </div>
          <div class="mt-3">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/bukadulu_Images/bukadulu_ImgID1.png" alt="buka dulu">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/acaramedia_Images/acaramedia_ImgID1.png" alt="acara media">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/kost_mlg_Images/kost_mlg_ImgID1.png" alt="kost malang">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/mhs_um_Images/mhs_um_ImgID1.png" alt="mahasiswa universitas negeri malang">
            <img class="media-partner-img" src="assets/landing/assets/Komunitas + MP/msp_Images/msp_ImgID1.png" alt="microsoft student partner">
          </div>
        </div>
      </div>
    </section>

    <section class="gallery">
      <div class="container py-3">
        <h2 class="section-title mb-2">GALLERY</h2>
        <p class="section-desc">The Documentation</p>
        <div class="row">
          <div class="col-md-4 col-xs-12">
            <img src="assets/landing/assets/uin_malikiPEpmA.jpg" class="gallery-img" alt="">
          </div>
          <div class="col-md-4 col-xs-12">
            <img src="assets/landing/assets/uin_malikiPEpmA.jpg" class="gallery-img" alt="">
          </div>
          <div class="col-md-4 col-xs-12">
            <img src="assets/landing/assets/uin_malikiPEpmA.jpg" class="gallery-img" alt="">
          </div>
          <div class="col-md-4 col-xs-12">
            <img src="assets/landing/assets/uin_malikiPEpmA.jpg" class="gallery-img" alt="">
          </div>
          <div class="col-md-4 col-xs-12">
            <img src="assets/landing/assets/uin_malikiPEpmA.jpg" class="gallery-img" alt="">
          </div>
          <div class="col-md-4 col-xs-12">
            <img src="assets/landing/assets/uin_malikiPEpmA.jpg" class="gallery-img" alt="">
          </div>
        </div>
      </div>
    </section>

    <section class="join">
      <div class="container text-center">
        <h2 class="section-title">JOIN WITH US NOW!</h2>
        <p class="section-desc">What do you waiting for?</p>
        <a href="<?php echo e(base_url('registrasi')); ?>" class="btn btn-primary mt-2">JOIN IN</a>
      </div>
    </section>

    <section class="contact bg-icon">
      <div class="container-fluid py-3">
        <div class="text-center mb-5">
          <h2 class="section-title">CONTACT</h2>
          <p class="section-desc">Contact us for more information needed</p>
        </div>
        <div class="row">
          <div class="col-md-3">
            <div class="feedback">
              <p class="send mb-4 text-center text-primary">Send your feedback</p>
              <form class="form-group">
                <input type="text" class="my-3 form-control" placeholder="Full Name">
                <input type="email" class="my-3 form-control" placeholder="Email">
                <textarea class="my-3 textarea form-control" placeholder="Message"></textarea>
                <a href="#" class="btn btn-primary mt-3 form-control">SUBMIT</a>
              </form>
              <div class="social-media mt-2 text-center">
                <p class="desc mt-5">Visit us on our Social Media :</p>
                <div class="socmed-link">
                  <a href="#" target="_blank">
                    <i class="fa fa-facebook"></i>
                  </a>
                  <a href="#" target="_blank">
                    <i class="fa fa-instagram"></i>
                  </a>
                  <a href="#" target="_blank">
                    <i class="fa fa-globe"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-9">
            <iframe class="gmaps" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.4556108184784!2d112.60526401428687!3d-7.951779081426514!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e78815e45bbc56d%3A0x5031ab2d7d36dba6!2sUIN+Maulana+Malik+Ibrahim!5e0!3m2!1sen!2sid!4v1532623220110"
              frameborder="0" style="border:0;" allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </section>

    <footer class="footer row py-5">
      <p class="desc">Supported by</p>
      <img class="img-footer" src="assets/landing/assets/Komunitas + MP/eth0_Images/eth0_ImgID1.png" alt="Komunitas UIN Maulana Malik Ibrahim Malang">
      <img class="img-footer" src="assets/landing/assets/Komunitas + MP/mocap_Images/mocap_ImgID1.png" alt="Komunitas UIN Maulana Malik Ibrahim Malang">
      <img class="img-footer" src="assets/landing/assets/Komunitas + MP/mamud_Images/mamud_ImgID1.png" alt="Komunitas UIN Maulana Malik Ibrahim Malang">
      <img class="img-footer" src="assets/landing/assets/Komunitas + MP/fun_java_Images/fun_java_ImgID1.png" alt="Komunitas UIN Maulana Malik Ibrahim Malang">
      <img class="img-footer" src="assets/landing/assets/Komunitas + MP/ontaki_Images/ontaki_ImgID1.png" alt="Komunitas UIN Maulana Malik Ibrahim Malang">
      <img class="img-footer" src="assets/landing/assets/Komunitas + MP/uinbuntu_Images/uinbuntu_ImgID1.png" alt="Komunitas UIN Maulana Malik Ibrahim Malang">
      <img class="img-footer" src="assets/landing/assets/Komunitas + MP/weboender_Images/weboender_ImgID1.png" alt="Komunitas UIN Maulana Malik Ibrahim Malang">
    </footer>

  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.5.16/vue.js"></script>
  <script src="assets/landing/js/main.js"></script>
</body>

</html>