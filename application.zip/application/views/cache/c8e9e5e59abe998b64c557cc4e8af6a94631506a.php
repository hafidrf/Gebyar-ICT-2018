<!DOCTYPE html>
<html lang="en">
	<head>
	<title><?php echo $__env->yieldContent('title', 'ICT'); ?></title>

	  	<?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</head>
<body>

			<?php  $CI = &get_instance();  ?>

              <?php if($CI->session->flashdata('error')): ?>
                <div class="alert alert-danger" role="alert">
                  <?php echo $CI->session->flashdata('error'); ?>

                </div>
              <?php endif; ?>
              
	<section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content">
      <div class="logo">
        <h1 class="registrasi-title"> Registrasi</h1>
      </div>
      <div class="login-box">
			
			<?php 
				$attributes = array('class' => 'login-form');
				echo form_open('registrasi', $attributes);
			 ?>
				<h3 class="login-head">
				<i class="fa fa-lg fa-fw fa-user"></i>Registrasi
				</h3>

				<div class="form-row">
					<div class="col form-group">
						<label>Nama Tim</label>
						<?php echo form_error('nama_tim'); ?>   
					  	<input type="text" class="form-control <?php echo e(has_error('nama_tim')); ?>" placeholder="Nama Tim" name="nama_tim" value="<?php echo set_value('nama_tim'); ?>">
					</div> 
				</div>
				<div class="form-row">
					<div class="col form-group">
						<label>Nama Captain</label>  
						<?php echo form_error('nama_captain'); ?>  
					  	<input type="text" class="form-control <?php echo e(has_error('nama_captain')); ?>" placeholder="Nama Captain" name="nama_captain" value="<?php echo set_value('nama_captain'); ?>">
					</div> 
				</div>
				<div class="form-row">
					<div class="col form-group">
						<label>Nama Anggota 1</label>
						<?php echo form_error('anggota1'); ?>    
					  	<input type="text" class="form-control <?php echo e(has_error('anggota1')); ?>" placeholder="Nama Anggota 1" name="anggota1" value="<?php echo set_value('anggota1'); ?>">
					</div> 
				</div>
				<div class="form-row">
					<div class="col form-group">
						<label>Nama Anggota 2</label> 
						<?php echo form_error('anggota2'); ?>   
					  	<input type="text" class="form-control <?php echo e(has_error('anggota2')); ?>" placeholder="Nama Anggota 2" name="anggota2" value="<?php echo set_value('anggota2'); ?>">
					</div> 
				</div>
				
				<div class="form-group">
					<label>Kategori Lomba</label>
					<?php echo form_error('kategori_lomba'); ?> 
					<select class="form-control select <?php echo e(has_error('kategori_lomba')); ?>" name="kategori_lomba">
						<option>Pilih Kategori</option>
						<?php $__currentLoopData = $kategori_lomba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->nama_kategori); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					
				</div> 
				<div id="judul_aplikasi" class="form-group" style="display: none;">
					<label>Judul Aplikasi</label>
					<?php echo form_error('judul_aplikasi'); ?>

					<input class="form-control <?php echo e(has_error('judul_aplikasi')); ?>" type="text" name="judul_aplikasi">
				</div>
				
				<div class="form-group">	
					<label>Email</label>
					<?php echo form_error('email'); ?>    
				  	<input type="email" class="form-control <?php echo e(has_error('email')); ?>" placeholder="Email" name="email" value="<?php echo set_value('email'); ?>">
				</div>

				<div class="form-group">
					<label>Password</label>
					<?php echo form_error('password'); ?> 
				    <input class="form-control <?php echo e(has_error('password')); ?>" type="password" name="password">
				</div>
				<div class="form-group">
					<label>Ulangi Password</label>
					<?php echo form_error('passconf'); ?> 
				    <input class="form-control <?php echo e(has_error('passconf')); ?>" type="password" name="passconf">
				</div> 
			    <div class="form-group">
			        <button type="submit" class="btn btn-secondary btn-block"> Register  </button>
			    </div>      
			                                           
			</form>
			</article> <!-- card-body end .// -->
			<div class="border-top card-body text-center"> 
				Sudah punya akun ?
				<a href="<?php echo e(base_url('login')); ?>">Login</a></div>
			</div>
			</section>
	<script type="text/javascript" src="<?php echo e(base_url('assets/js/jquery-3.2.1.slim.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(base_url('assets/js/popper.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(base_url('assets/js/bootstrap.min.js')); ?>"></script>
	<script type="text/javascript">
		$(".select").change(function(){
			if (this.value != 1){
				$("#judul_aplikasi").show();
			}else{
				$("#judul_aplikasi").hide();
			}
		});
	</script>
	<?php echo $__env->make('partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>