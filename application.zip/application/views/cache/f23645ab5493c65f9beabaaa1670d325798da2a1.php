<?php $__env->startSection('title', 'ICT | Dashboard'); ?>
<?php $__env->startSection('content'); ?>
	<?php 
		echo form_open(base_url('user/link/submit'))
	 ?>
		<div class="tile">
			<div class="form-row">
					<div class="col form-group">
						<label>Masukkan Link Video</label>  
					  	<input type="text" class="form-control" placeholder="Link Video" name="link_video" value="<?=$user->link_video ?>">
					</div> 
				</div>
				<button type="submit" class="btn btn-primary">Simpan</button>
          </form>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>