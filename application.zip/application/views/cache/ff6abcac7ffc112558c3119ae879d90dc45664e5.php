    <script src="<?php echo e(base_url('assets/js/jquery-3.2.1.slim.min.js')); ?>"></script>
    <script src="<?php echo e(base_url('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(base_url('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(base_url('assets/js/main.js')); ?>"></script>
    <!-- The javascript plugin to display page loading on top-->
   