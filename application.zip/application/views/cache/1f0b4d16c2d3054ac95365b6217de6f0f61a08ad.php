<?php $__env->startSection('title', 'ICT-Admin | Dashboard'); ?>
<?php $__env->startSection('content'); ?>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Pembayaran</h3>
           
            <table class="table table-stripped table-responsive" id="user">
              <thead>
                <th>No</th>
                <th>Email</th>
                <th>Ketua</th>
                <th>Kategori Lomba</th>
                <th>Judul</th>
                <th>Nama Tim</th>
                <th>Anggota</th>
                
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($user->email); ?></td>
                  <td><?php echo e($user->nama); ?></td>
                  <td><?php echo e($user->nama_kategori); ?></td>
                  <td><?php echo e($user->judul_aplikasi); ?></td>
                  <td><?php echo e($user->nama_tim); ?></td>
                  <td>
                    <ul>
                      <li><?php echo e($user->anggota_1); ?></li>
                      <li><?php echo e($user->anggota_2); ?></li>
                    </ul>
                  </td>
                 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="7"> Belum ada peserta terdaftar</td>
                </tr>
                <?php endif; ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(base_url('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(base_url('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script type="text/javascript">
      $(document).ready(function() {
          $('#user').DataTable();
      } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>