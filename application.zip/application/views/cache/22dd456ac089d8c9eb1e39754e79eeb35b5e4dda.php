    <aside class="app-sidebar">
      <div class="app-sidebar__user">
      <img class="app-sidebar__user-avatar" src="https://s3.amazonaws.com/uifaces/faces/twitter/jsa/48.jpg" alt="User Image">
        <div>
          <p class="app-sidebar__user-name">John Doe</p>
          <p class="app-sidebar__user-designation">Frontend Developer</p>
        </div>
      </div>
      <ul class="app-menu">
        <?php 
          $CI = &get_instance();

         ?>
        <li>
        <?php if($CI->session->userdata('logged_in') == 'user'): ?>        
          <a class="app-menu__item " href="<?php echo e(base_url('user/dashboard')); ?>">
        <?php else: ?>
          <a class="app-menu__item " href="<?php echo e(base_url('admin/dashboard')); ?>">
        <?php endif; ?>
          <i class="app-menu__icon fa fa-dashboard"></i>
          <span class="app-menu__label">Dashboard</span></a>
        </li>

        <?php if($CI->session->userdata('logged_in') == 'admin'): ?>
        <li>
          <a class="app-menu__item" href="<?php echo e(base_url('admin/data-pembayaran')); ?>">
          <i class="app-menu__icon fa fa-user"></i>
          <span class="app-menu__label">Konfirmasi Pembayaran</span></a>
        </li>
        <?php endif; ?>
       
        <?php if($CI->session->userdata('logged_in') == 'user'): ?>
         
        <li>     
          <a class="app-menu__item" href="<?php echo e(base_url('user/unggah-proposal')); ?>">
         <i class="app-menu__icon fa fa-upload"></i>
          <span class="app-menu__label">Unggah Proposal</span></a>
        </li>
         
        <?php else: ?>

        <?php endif; ?>
      </ul>
    </aside>