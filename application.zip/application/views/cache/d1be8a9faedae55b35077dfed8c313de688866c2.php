<!DOCTYPE html>
<html>
<head>
	<title>Registrasi</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(base_url('asset/css/bootstrap.min.css')); ?>">
</head>
<body>

</body>
</html>