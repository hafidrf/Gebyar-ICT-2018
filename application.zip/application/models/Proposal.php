<?php 
defined('BASEPATH') or exit('No direct script access allowed');

class Proposal extends CI_model
{
    private $table = 'proposal';

    public function insert($data)
    {
    	$this->db->insert($this->table, $data);
    	return $this->db->affected_rows();
    }

    public function getProposal($id)
    {
    	$this->db->where('user_id', $id);
    	return $this->db->get($this->table)->row();
    }

}